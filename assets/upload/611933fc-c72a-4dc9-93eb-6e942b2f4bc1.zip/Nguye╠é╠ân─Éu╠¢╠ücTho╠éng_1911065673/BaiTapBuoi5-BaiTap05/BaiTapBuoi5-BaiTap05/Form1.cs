﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaiTapBuoi5_BaiTap05
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        // Tính Kw tiêu thụ
        int chisocu;
        int chisomoi;
        int sokwtieuthu;
        int tongtien;

        private void TinhKwTieuThu ()       
        {
            // Nhập Chỉ số cũ và Chỉ số mới
            chisocu = Convert.ToInt32(txtChiSoCu.Text);
            chisomoi = Convert.ToInt32(txtChiSoMoi.Text);

            // Tính số Kw tiêu thụ
            sokwtieuthu = chisomoi - chisocu;

            if (sokwtieuthu < 0)   // Số Kw tiêu thụ không phải là số âm và chỉ số mới phải lớn hơn chỉ số cũ
            {
                MessageBox.Show("Nhập số cũ và số mới sai! Số mới phải lớn hơn số cũ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtChiSoCu.Clear();
                txtChiSoMoi.Clear();
                txtChiSoCu.Focus();
                return;
            }

            // in ra kết quả phép tính của Số Kw tiêu thụ (textBox)
            txtSoKwTieuThu.Text = Convert.ToString(sokwtieuthu);
        }

        // Hàm tính tiền 
        private void bttTinhTien_Click(object sender, EventArgs e)
        {
            // Nếu Combobox chọn Sinh hoạt
            if (cbbHinhThucTieuThu.Text == "Sinh hoạt")
            {
                TinhKwTieuThu();     

                if (sokwtieuthu <= 100) // Trong định mức
                {
                    txtDonGiaTrongDinhMuc.Text = Convert.ToString(450);
                    txtDonGiaNgoaiDinhMuc.Text = Convert.ToString(1020);

                    tongtien = sokwtieuthu * 450;
                    txtTongTien.Text = Convert.ToString(tongtien);
                }
                else  // Ngược lại > 100 Kw, ngoài định mức
                {
                    txtDonGiaTrongDinhMuc.Text = Convert.ToString(450);
                    txtDonGiaNgoaiDinhMuc.Text = Convert.ToString(1020);

                    tongtien = sokwtieuthu * 1020;
                    txtTongTien.Text = Convert.ToString(tongtien);
                }
            }
            //Nếu Combobox chọn Sản xuất
            if (cbbHinhThucTieuThu.Text == "Sản xuất")
            {
                TinhKwTieuThu();     

                if (sokwtieuthu <= 500) // Trong định mức
                {
                    txtDonGiaTrongDinhMuc.Text = Convert.ToString(550);
                    txtDonGiaNgoaiDinhMuc.Text = Convert.ToString(1100);

                    tongtien = sokwtieuthu * 550;
                    txtTongTien.Text = Convert.ToString(tongtien);
                }
                else  // Ngược lại > 500 Kw, ngoài định mức
                {
                    txtDonGiaTrongDinhMuc.Text = Convert.ToString(550);
                    txtDonGiaNgoaiDinhMuc.Text = Convert.ToString(1100);

                    tongtien = sokwtieuthu * 1100;
                    txtTongTien.Text = Convert.ToString(tongtien);
                }
            }
            //Nếu Combobox chọn Dịch vụ
            if (cbbHinhThucTieuThu.Text == "Dịch vụ")
            {
                TinhKwTieuThu();     

                if (sokwtieuthu <= 350) // Trong định mức
                {
                    txtDonGiaTrongDinhMuc.Text = Convert.ToString(780);
                    txtDonGiaNgoaiDinhMuc.Text = Convert.ToString(1550);

                    tongtien = sokwtieuthu * 780;
                    txtTongTien.Text = Convert.ToString(tongtien);
                }
                else  // Ngược lại > 350 Kw, ngoài định mức
                {
                    txtDonGiaTrongDinhMuc.Text = Convert.ToString(780);
                    txtDonGiaNgoaiDinhMuc.Text = Convert.ToString(1550);

                    tongtien = sokwtieuthu * 1550;
                    txtTongTien.Text = Convert.ToString(tongtien);
                }
            }

            // In nội dung Kết quả 
            labelNoiDungKetQua.Text = " Ông/ Bà " + txtHoTen.Text + "\r\n" + 
                                      " Đã sử dụng " + sokwtieuthu +" Kw " +"\r\n" + 
                                      " Thuộc hình thức tiêu thụ: " + cbbHinhThucTieuThu.Text + "\r\n" +
                                      " Với tổng số tiền là " + tongtien +" đồng ";
        }

        private void txtDinhMuc_TextChanged(object sender, EventArgs e)
        {
  
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtDonGiaTrongDinhMuc_TextChanged(object sender, EventArgs e)
        {
           

        }
        //Combox Hình thức tiêu thụ 
        private void cbbHinhThucTieuThu_SelectedIndexChanged(object sender, EventArgs e)
        {
            {
                if (txtHoTen.Text.Trim().Length == 0 || txtChiSoCu.Text.Trim().Length == 0 || txtChiSoMoi.Text.Trim().Length == 0 || cbbHinhThucTieuThu.Text.Trim().Length == 0)
                {
                    bttTinhTien.Enabled = false;
                }
                else
                    bttTinhTien.Enabled = true;
            }

            if (cbbHinhThucTieuThu.Text == "Sinh hoạt")
            {
                txtDinhMuc.Text = "100";
                txtDonGiaTrongDinhMuc.Text = "450";
                txtDonGiaNgoaiDinhMuc.Text = "1020";
            }

            if (cbbHinhThucTieuThu.Text == "Sản xuất")
            {
                txtDinhMuc.Text = "500";
                txtDonGiaTrongDinhMuc.Text = "550";
                txtDonGiaNgoaiDinhMuc.Text = "1100";
            }

            if (cbbHinhThucTieuThu.Text == "Dịch vụ")
            {
                txtDinhMuc.Text = "350";
                txtDonGiaTrongDinhMuc.Text = "780";
                txtDonGiaNgoaiDinhMuc.Text = "1550";
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void labelNoiDungKetQua_Click(object sender, EventArgs e)
        {

        }

        private void txtHoTen_TextChanged(object sender, EventArgs e)
        {
            {
                if (txtHoTen.Text.Trim().Length == 0 || txtChiSoCu.Text.Trim().Length == 0 || txtChiSoMoi.Text.Trim().Length == 0 || cbbHinhThucTieuThu.Text.Trim().Length == 0)
                {
                    bttTinhTien.Enabled = false;
                }
                else
                    bttTinhTien.Enabled = true;
            }
        }

            private void bttThoát_Click(object sender, EventArgs e)
        {
            DialogResult thoat = MessageBox.Show("Bạn muốn kết thúc chương trình không ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (thoat == DialogResult.Yes)
                Close();
        }

        private void txtTongTien_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSoKwTieuThu_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtChiSoCu_TextChanged(object sender, EventArgs e)
        {
            {
                if (txtHoTen.Text.Trim().Length == 0 || txtChiSoCu.Text.Trim().Length == 0 || txtChiSoMoi.Text.Trim().Length == 0 || cbbHinhThucTieuThu.Text.Trim().Length == 0)
                {
                    bttTinhTien.Enabled = false;
                }
                else
                    bttTinhTien.Enabled = true;
            }
        }

        private void txtChiSoMoi_TextChanged(object sender, EventArgs e)
        {
            {
                if (txtHoTen.Text.Trim().Length == 0 || txtChiSoCu.Text.Trim().Length == 0 || txtChiSoMoi.Text.Trim().Length == 0 || cbbHinhThucTieuThu.Text.Trim().Length == 0)
                {
                    bttTinhTien.Enabled = false;
                }
                else
                    bttTinhTien.Enabled = true;
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
}






