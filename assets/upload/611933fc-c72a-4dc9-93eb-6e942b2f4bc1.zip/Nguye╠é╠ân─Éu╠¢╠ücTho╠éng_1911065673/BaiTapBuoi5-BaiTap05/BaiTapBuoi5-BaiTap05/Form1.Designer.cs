﻿
namespace BaiTapBuoi5_BaiTap05
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cbbHinhThucTieuThu = new System.Windows.Forms.ComboBox();
            this.bttTinhTien = new System.Windows.Forms.Button();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDinhMuc = new System.Windows.Forms.TextBox();
            this.txtDonGiaTrongDinhMuc = new System.Windows.Forms.TextBox();
            this.txtDonGiaNgoaiDinhMuc = new System.Windows.Forms.TextBox();
            this.txtChiSoCu = new System.Windows.Forms.TextBox();
            this.txtChiSoMoi = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.labelNoiDungKetQua = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtSoKwTieuThu = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.bttThoát = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(57, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Họ tên chủ hộ";
            // 
            // cbbHinhThucTieuThu
            // 
            this.cbbHinhThucTieuThu.FormattingEnabled = true;
            this.cbbHinhThucTieuThu.Items.AddRange(new object[] {
            "Sinh hoạt",
            "Sản xuất",
            "Dịch vụ"});
            this.cbbHinhThucTieuThu.Location = new System.Drawing.Point(146, 65);
            this.cbbHinhThucTieuThu.Name = "cbbHinhThucTieuThu";
            this.cbbHinhThucTieuThu.Size = new System.Drawing.Size(121, 21);
            this.cbbHinhThucTieuThu.TabIndex = 1;
            this.cbbHinhThucTieuThu.SelectedIndexChanged += new System.EventHandler(this.cbbHinhThucTieuThu_SelectedIndexChanged);
            // 
            // bttTinhTien
            // 
            this.bttTinhTien.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttTinhTien.ForeColor = System.Drawing.Color.Red;
            this.bttTinhTien.Location = new System.Drawing.Point(290, 119);
            this.bttTinhTien.Name = "bttTinhTien";
            this.bttTinhTien.Size = new System.Drawing.Size(89, 78);
            this.bttTinhTien.TabIndex = 2;
            this.bttTinhTien.Text = "Tính tiền";
            this.bttTinhTien.UseVisualStyleBackColor = true;
            this.bttTinhTien.Click += new System.EventHandler(this.bttTinhTien_Click);
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(146, 27);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(146, 20);
            this.txtHoTen.TabIndex = 3;
            this.txtHoTen.TextChanged += new System.EventHandler(this.txtHoTen_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Hình thức tiêu thụ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(82, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Định mức";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Đơn giá trong định mức";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 169);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "Đơn giá ngoài định mức";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(83, 204);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 15);
            this.label6.TabIndex = 8;
            this.label6.Text = "Chỉ số cũ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(77, 237);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 15);
            this.label7.TabIndex = 9;
            this.label7.Text = "Chỉ số mới";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // txtDinhMuc
            // 
            this.txtDinhMuc.Location = new System.Drawing.Point(146, 97);
            this.txtDinhMuc.Name = "txtDinhMuc";
            this.txtDinhMuc.ReadOnly = true;
            this.txtDinhMuc.Size = new System.Drawing.Size(105, 20);
            this.txtDinhMuc.TabIndex = 10;
            this.txtDinhMuc.TextChanged += new System.EventHandler(this.txtDinhMuc_TextChanged);
            // 
            // txtDonGiaTrongDinhMuc
            // 
            this.txtDonGiaTrongDinhMuc.Location = new System.Drawing.Point(146, 131);
            this.txtDonGiaTrongDinhMuc.Name = "txtDonGiaTrongDinhMuc";
            this.txtDonGiaTrongDinhMuc.ReadOnly = true;
            this.txtDonGiaTrongDinhMuc.Size = new System.Drawing.Size(105, 20);
            this.txtDonGiaTrongDinhMuc.TabIndex = 11;
            this.txtDonGiaTrongDinhMuc.TextChanged += new System.EventHandler(this.txtDonGiaTrongDinhMuc_TextChanged);
            // 
            // txtDonGiaNgoaiDinhMuc
            // 
            this.txtDonGiaNgoaiDinhMuc.Location = new System.Drawing.Point(146, 167);
            this.txtDonGiaNgoaiDinhMuc.Name = "txtDonGiaNgoaiDinhMuc";
            this.txtDonGiaNgoaiDinhMuc.ReadOnly = true;
            this.txtDonGiaNgoaiDinhMuc.Size = new System.Drawing.Size(105, 20);
            this.txtDonGiaNgoaiDinhMuc.TabIndex = 12;
            // 
            // txtChiSoCu
            // 
            this.txtChiSoCu.Location = new System.Drawing.Point(146, 202);
            this.txtChiSoCu.Name = "txtChiSoCu";
            this.txtChiSoCu.Size = new System.Drawing.Size(105, 20);
            this.txtChiSoCu.TabIndex = 13;
            this.txtChiSoCu.TextChanged += new System.EventHandler(this.txtChiSoCu_TextChanged);
            // 
            // txtChiSoMoi
            // 
            this.txtChiSoMoi.Location = new System.Drawing.Point(146, 232);
            this.txtChiSoMoi.Name = "txtChiSoMoi";
            this.txtChiSoMoi.Size = new System.Drawing.Size(105, 20);
            this.txtChiSoMoi.TabIndex = 14;
            this.txtChiSoMoi.TextChanged += new System.EventHandler(this.txtChiSoMoi_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(372, 43);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(155, 22);
            this.label8.TabIndex = 15;
            this.label8.Text = "Kết quả tính tiền: ";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // labelNoiDungKetQua
            // 
            this.labelNoiDungKetQua.AutoSize = true;
            this.labelNoiDungKetQua.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNoiDungKetQua.Location = new System.Drawing.Point(391, 82);
            this.labelNoiDungKetQua.Name = "labelNoiDungKetQua";
            this.labelNoiDungKetQua.Size = new System.Drawing.Size(61, 17);
            this.labelNoiDungKetQua.TabIndex = 16;
            this.labelNoiDungKetQua.Text = "Ông/ Bà:";
            this.labelNoiDungKetQua.Click += new System.EventHandler(this.labelNoiDungKetQua_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(54, 268);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 15);
            this.label9.TabIndex = 17;
            this.label9.Text = "Số Kw tiêu thụ";
            // 
            // txtSoKwTieuThu
            // 
            this.txtSoKwTieuThu.Location = new System.Drawing.Point(146, 266);
            this.txtSoKwTieuThu.Name = "txtSoKwTieuThu";
            this.txtSoKwTieuThu.ReadOnly = true;
            this.txtSoKwTieuThu.Size = new System.Drawing.Size(105, 20);
            this.txtSoKwTieuThu.TabIndex = 18;
            this.txtSoKwTieuThu.TextChanged += new System.EventHandler(this.txtSoKwTieuThu_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(298, 273);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "Tổng tiền: ";
            // 
            // txtTongTien
            // 
            this.txtTongTien.Location = new System.Drawing.Point(362, 268);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.ReadOnly = true;
            this.txtTongTien.Size = new System.Drawing.Size(105, 20);
            this.txtTongTien.TabIndex = 20;
            this.txtTongTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTongTien.TextChanged += new System.EventHandler(this.txtTongTien_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(473, 273);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "Đ";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // bttThoát
            // 
            this.bttThoát.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttThoát.Location = new System.Drawing.Point(536, 258);
            this.bttThoát.Name = "bttThoát";
            this.bttThoát.Size = new System.Drawing.Size(89, 33);
            this.bttThoát.TabIndex = 22;
            this.bttThoát.Text = "Thoát";
            this.bttThoát.UseVisualStyleBackColor = true;
            this.bttThoát.Click += new System.EventHandler(this.bttThoát_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(257, 138);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 13);
            this.label12.TabIndex = 23;
            this.label12.Text = "Đ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(257, 171);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 13);
            this.label13.TabIndex = 24;
            this.label13.Text = "Đ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(637, 303);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.bttThoát);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtTongTien);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtSoKwTieuThu);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.labelNoiDungKetQua);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtChiSoMoi);
            this.Controls.Add(this.txtChiSoCu);
            this.Controls.Add(this.txtDonGiaNgoaiDinhMuc);
            this.Controls.Add(this.txtDonGiaTrongDinhMuc);
            this.Controls.Add(this.txtDinhMuc);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtHoTen);
            this.Controls.Add(this.bttTinhTien);
            this.Controls.Add(this.cbbHinhThucTieuThu);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Tính tiền điện";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbbHinhThucTieuThu;
        private System.Windows.Forms.Button bttTinhTien;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDinhMuc;
        private System.Windows.Forms.TextBox txtDonGiaTrongDinhMuc;
        private System.Windows.Forms.TextBox txtDonGiaNgoaiDinhMuc;
        private System.Windows.Forms.TextBox txtChiSoCu;
        private System.Windows.Forms.TextBox txtChiSoMoi;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labelNoiDungKetQua;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtSoKwTieuThu;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtTongTien;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button bttThoát;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
    }
}

